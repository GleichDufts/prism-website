import React from "react";
import Module from "@/components/Module";

export default function Home() {
  const modules = [
    { title: "Bildanalyse", description: "Analysiert Bilder präzise, erkennt Details und strukturiert Inhalte visuell." },
    { title: "Texte verstehen", description: "Analysiert, interpretiert und bewertet Texte mit Zitatbelegen." },
    { title: "Dateien auswerten", description: "Liest PDFs, Tabellen, DOCX – erkennt Strukturen, Fehler, Kernaussagen." },
    { title: "Bilder generieren", description: "Erstellt realistische, stilvolle, kreative Bilder auf Anfrage." },
    { title: "Webrecherche", description: "Führt gezielte Recherchen durch und bewertet Quellen kritisch." }
  ];

  return (
    <div className="min-h-screen bg-black text-white px-4 py-8">
      <h1 className="text-4xl font-semibold text-center mb-10">PRISM AI</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
        {modules.map((mod, i) => (
          <Module key={i} title={mod.title} description={mod.description} />
        ))}
      </div>
    </div>
  );
}