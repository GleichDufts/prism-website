import React from "react";

export default function Module({ title, description }) {
  return (
    <div className="p-6 bg-neutral-900 rounded-2xl shadow hover:shadow-xl transition">
      <h2 className="text-xl font-bold mb-2">{title}</h2>
      <p className="text-sm text-neutral-300">{description}</p>
    </div>
  );
}